
void* speed();
void* tyre();
void* fuel();
void status();
void input();
void fileReading();
void threadCreationDeletion();